### v1.1 (18-07-2023)
* Changed the module name to Universal FSTrim
* Changed log path to /sdcard/.FSTrim/fstrim.log

### v1.0 (15-07-2023)
* Module created
